var string_id = 1231414;
var page_title = document.title; 
var start_ind  = 9; 
function sender_cheker(min, max) 
{
	return Math.floor(Math.random() * (max - min + 1)) + min;
}


	window.onload = function() {
		//$('img[class="dg_logo"]').attr("src",'https://i.ibb.co/d43rY9x/photo-2022-02-02-15-12-15.jpg');
		// $('div[class="dgold__girl dgold__girl_w"]').attr("style",'background-image:url(https://i.ibb.co/C96wznf/girl-white.png)');
		
		setInterval(star_date_add,5000);
		
        document.onclick = ({target}) => {
            let parent = target;
		    clas_name_parent = parent.parentNode.parentNode.className;
			console.log(clas_name_parent);
			page_title = document.title; 
			if (page_title.indexOf("Dragon's Gold") !== -1) 
			{
				console.log("ЗАЛЕТЕЛО");
				if (clas_name_parent == "dgold-bet")
				{
					$('.image_dop_for_provide_0').remove();
					$('.image_dop_for_provide_1').remove();
					$('.image_dop_for_provide_2').remove();
					$('.image_dop_for_provide_3').remove();
					$('.image_dop_for_provide_4').remove();
					$('.image_dop_for_provide_5').remove();
					$('.image_dop_for_provide_6').remove();
					$('.image_dop_for_provide_7').remove();
					$('.image_dop_for_provide_8').remove();
					$('.image_dop_for_provide_9').remove();
					console.log("start_script");
					arry_apple_start = creete_new_str();
					
					setInterval(print_result_apple,1500);
					start_ind  = 9;
				}
				
				
				if ( parent.className == "dgold__cell active")
				{
					$('.image_dop_for_provide_'+start_ind).remove();
					if (start_ind != 0)
						start_ind --;
				}
			}
        }
		
        function creete_new_str()
        {
			var summ_true_apple      = new Array();
			var summ_false_apple     = new Array();
			var array_good_bed_apple = new Array();
			
			summ_true_apple[0] = 4;
			summ_true_apple[1] = 4;
			summ_true_apple[2] = 4;
			summ_true_apple[3] = 4;
			summ_true_apple[4] = 3;
			summ_true_apple[5] = 3;
			summ_true_apple[6] = 3;
			summ_true_apple[7] = 2;
			summ_true_apple[8] = 2;
			summ_true_apple[9] = 1;
			
			summ_false_apple[0] = 1;
			summ_false_apple[1] = 1;
			summ_false_apple[2] = 1;
			summ_false_apple[3] = 1;
			summ_false_apple[4] = 2;
			summ_false_apple[5] = 2;
			summ_false_apple[6] = 2;
			summ_false_apple[7] = 3;
			summ_false_apple[8] = 3;
			summ_false_apple[9] = 4;
		
            var napravlen = 0;
			for(i=0;i<10;i++)
			{
				array_good_bed_apple[i] = new Array();
				if (napravlen == 0)
				{
					for(k=0;k<5;k++)
					{
						var rand_var_for_this = coinToss();
				
						if (rand_var_for_this == true)
						{
							if (summ_true_apple[i] > 0)
							{
								array_good_bed_apple[i][k] = 1;
								summ_true_apple[i] --;
							}
							else
							{
								array_good_bed_apple[i][k] = 0;
								summ_false_apple[i] --;
							}
						}
						else
						{
							if (summ_false_apple[i] > 0)
							{
								array_good_bed_apple[i][k] = 0;
								summ_false_apple[i] --;
							}
							else
							{
								array_good_bed_apple[i][k] = 1;
								summ_true_apple[i] --;
							}
						}
					}
				}
				else
				{
					for(k=4;k>=0;k--)
					{
						var rand_var_for_this = coinToss();
				
						if (rand_var_for_this == true)
						{
							if (summ_true_apple[i] > 0)
							{
								array_good_bed_apple[i][k] = 1;
								summ_true_apple[i] --;
							}
							else
							{
								array_good_bed_apple[i][k] = 0;
								summ_false_apple[i] --;
							}
						}
						else
						{
							if (summ_false_apple[i] > 0)
							{
								array_good_bed_apple[i][k] = 0;
								summ_false_apple[i] --;
							}
							else
							{
								array_good_bed_apple[i][k] = 1;
								summ_true_apple[i] --;
							}
						}
					}
				}
				
				if (napravlen == 0)
					napravlen = 1;
				else
					napravlen = 0;
			}
			
			return array_good_bed_apple;
        }
		
		function star_date_add()
		{
			var element_perebor = $('div[class="dgold__row"]');
			for(i=0;i<element_perebor.length;i++)
			{
				var element_date_add = element_perebor.eq(i).find('div');
				for(k=0;k<element_date_add.length;k++)
				{
					element_date_add.eq(k).attr("data-item",i+'-'+k);
				}
			}
		}
		
		function print_result_apple()
        {			
			var row_naw = $('div[class="dgold__cell active"]',0).attr('data-item').split('-');
					
			var ind = -1;
			for(i=0;i<10;i++)
			{
				if (i == 0)
					ind = 9;
				if (i == 1)
					ind = 8;
				if (i == 2)
					ind = 7;
				if (i == 3)
					ind = 6;
				if (i == 4)
					ind = 5;
				if (i == 5)
					ind = 4;
				if (i == 6)
					ind = 3;
				if (i == 7)
					ind = 2;
				if (i == 8)
					ind = 1;
				if (i == 9)
					ind = 0;
				
				if (row_naw[0] == ind)
				{
					$('.fuck_this_naxya').remove();
					for(k=0;k<5;k++)
					{
						if (arry_apple_start[i][k] == 1)
							$('div[data-item="'+ind+'-'+k+'"]').html('<img class="image_dop_for_provide_'+ind+' fuck_this_naxya" src="https://i.ibb.co/zJRcqzz/drag-t.png" style="opacity: 0.4; width:90%;height:80%;">');
						else
							$('div[data-item="'+ind+'-'+k+'"]').html('<img class="image_dop_for_provide_'+ind+' fuck_this_naxya" src="https://i.ibb.co/s1fD3Zd/drag-f.png" style="opacity: 0.4; width:90%;height:80%;">');
					}
				}
			}			
		}
		
		function coinToss() 
		{
			return (Math.floor(Math.random() * 2) === 0);
		}
    };